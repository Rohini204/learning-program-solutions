import java.util.Arrays;

public class Library {

    // Linear search
    public static Book linearSearch(Book[] books, String title) {
        for (Book book : books) {
            if (book.title.equalsIgnoreCase(title)) {
                return book;
            }
        }
        return null;
    }

    // Binary search (requires sorted array)
    public static Book binarySearch(Book[] books, String title) {
        int low = 0;
        int high = books.length - 1;

        while (low <= high) {
            int mid = (low + high) / 2;
            int comparison = books[mid].title.compareToIgnoreCase(title);

            if (comparison == 0) {
                return books[mid];
            } else if (comparison < 0) {
                low = mid + 1;
            } else {
                high = mid - 1;
            }
        }

        return null;
    }

    // Sort books by title (needed before binary search)
    public static void sortBooksByTitle(Book[] books) {
        Arrays.sort(books, (a, b) -> a.title.compareToIgnoreCase(b.title));
    }
}
