public class PayPalGateway {
    public void sendPayment(double amountInUSD) {
        System.out.println("Paid $" + amountInUSD + " using PayPal.");
    }
}
